package com.huangjunqiang.www.Dao;

import javax.swing.*;

/**
 * Create with IntelliJ IDEA
 *
 * @author: hjq
 * @Date:
 * @Description:
 */
public interface BarDao {
    public abstract void insertBar(JTextField id,JTextField barName,JTextField desc,JTextField time,JTextField sid);
    public abstract void deleteBar(JTextField id);
    public abstract void resetBar(JTextField id,JTextField barName,JTextField desc,JTextField time,JTextField sid);
}

package com.huangjunqiang.www.Dao;

import javax.swing.*;

/**
 * Create with IntelliJ IDEA
 *
 * @author: hjq
 * @Date:
 * @Description:
 */
public interface PostDao {
    public abstract void addPost(JTextField idField, JTextField nameField, JTextField titleField, JTextField contentField,JTextField authorField, JTextField timeField);
    public abstract void deletePost(JTextField idField);
    public abstract void resetPost(JTextField idField,JTextField nameField,JTextField titleField, JTextField contentField ,JTextField authorField,JTextField timeField);
}

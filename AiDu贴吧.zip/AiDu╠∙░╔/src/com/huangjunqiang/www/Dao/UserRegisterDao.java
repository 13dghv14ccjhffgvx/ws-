package com.huangjunqiang.www.Dao;

import com.huangjunqiang.www.po.User;

import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * Create with IntelliJ IDEA
 *
 * @author: hjq
 * @Date:
 * @Description:
 */
public class UserRegisterDao {
    public int register(Connection conn, User user) throws Exception{
        String sql= "insert into user values(null,?,?,?,?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, user.getUsername());
        ps.setString(2, user.getPassword());
        ps.setString(3, user.getNickname());
        ps.setString(4, user.getBirthday());
        return ps.executeUpdate();
    }
}

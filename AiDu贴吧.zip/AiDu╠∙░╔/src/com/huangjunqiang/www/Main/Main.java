package com.huangjunqiang.www.Main;

import com.huangjunqiang.www.View.StartView;

/**
 * Create with IntelliJ IDEA
 *
 * @author: hjq
 * @Date:
 * @Description:
 */
public class Main {
    public static void main(String[] args) {
        new StartView();
    }
}

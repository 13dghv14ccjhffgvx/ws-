package com.huangjunqiang.www.View.MasterView;

import com.huangjunqiang.www.Dao.MasterLoginDao;
import com.huangjunqiang.www.Util.JdbcUtils;
import com.huangjunqiang.www.Util.StringUtil;
import com.huangjunqiang.www.View.StartView;
import com.huangjunqiang.www.po.Master;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

/**
 * Create with IntelliJ IDEA
 *
 * @author: hjq
 * @Date:
 * @Description:
 */
public class MasterLoginView extends JFrame {
    Connection conn=null;
    MasterLoginDao m=new MasterLoginDao();
    private final Container container=getContentPane();
    private final JLabel userLabel=new JLabel("用户名: ");
    public static JTextField usernameField=new JTextField(15);
    private final JLabel pwdLabel=new JLabel("密    码: ");
    private final JPasswordField pwdField=new JPasswordField(15);
    private final JButton okButton=new JButton("确定");
    private final JButton cancelButton=new JButton("取消");
    public MasterLoginView(){
        setTitle("管理员登录界面");
        //设置窗口大小
        setBounds(600,300,400,200);
        //添加一块桌布
        container.setLayout(new BorderLayout());
        //初始化窗口
        init();
        //设计窗口可见
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public void init() {
        JPanel root = new JPanel();
        root.setLayout(null);
        userLabel.setBounds(70, 30, 50, 20);
        pwdLabel.setBounds(70, 70, 50, 20);
        root.add(userLabel);
        root.add(pwdLabel);
        usernameField.setBounds(120, 32, 160, 20);
        pwdField.setBounds(120, 72, 160, 20);
        root.add(usernameField);
        root.add(pwdField);
        okButton.setBounds(80,120,65,36);
        cancelButton.setBounds(200,120,65,36);
        root.add(okButton);
        root.add(cancelButton);
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loginActionPerformed(e);
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new StartView();
                dispose();
            }
        });
        container.add(root);
    }

    private void loginActionPerformed(ActionEvent e) {
        String username =usernameField.getText();
        String password =pwdField.getText();
        if(StringUtil.isEmpty(username)){
            JOptionPane.showMessageDialog(null,"用户名不能为空!");
            return;
        }if(StringUtil.isEmpty(password)){
            JOptionPane.showMessageDialog(null,"密码不能为空!");
            return;
        }
        Master master = new Master(username,password);
        try {
            conn = JdbcUtils.getConnection();
            Master currentUser =m.login(conn,master);
            if(currentUser!=null){
                JOptionPane.showMessageDialog(null,"登陆成功");
                new MasterMainView();
                dispose();
            }else{
                JOptionPane.showMessageDialog(null,"用户名或密码错误");
            }
        }catch (Exception ex) {
            ex.printStackTrace();
        }finally {
            try{
                if(conn!=null){
                    conn.close();
                }
            }catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new MasterLoginView();
    }

}

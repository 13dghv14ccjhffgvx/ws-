package com.huangjunqiang.www.View.MasterView;

import com.huangjunqiang.www.View.BarView;
import com.huangjunqiang.www.View.PostView;
import com.huangjunqiang.www.View.StartView;
import com.huangjunqiang.www.View.UserView.UserRegisterView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Create with IntelliJ IDEA
 *
 * @author: hjq
 * @Date:
 * @Description:
 */
public class MasterMainView extends JFrame{
    private final Container container =getContentPane();
    private final JButton postBarButton=new JButton("贴吧管理");
    private final JButton postMessageButton=new JButton("帖子管理");
    private final JButton userButton=new JButton("用户管理");
    private final JButton backButton=new JButton("返回始界面");
    private UserRegisterView r=new UserRegisterView();
    public MasterMainView() {
        setTitle("管理员主界面");
        //设置窗口大小
        setBounds(620,160,400,620);
        //添加一块桌布
        container.setLayout(new BorderLayout());
        //初始化窗口
        init();
        //设计窗口可见
        setVisible(true);
    }
    public void init() {
        JPanel root = new JPanel();
        root.setLayout(null);
        postBarButton.setBounds(5,1,370,130);
        postBarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new BarView().showPostBar();
            }
        });
        postMessageButton.setBounds(5,150,370,130);
        userButton.setBounds(5,300,370,130);
        backButton.setBounds(5,450,370,130);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new StartView();
                dispose();
            }
        });
        postMessageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PostView().masterPost();
                dispose();
            }
        });
        userButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new UserMasterView();
                dispose();
            }
        });
        root.add(postBarButton);
        root.add(postMessageButton);
        root.add(userButton);
        root.add(backButton);
        container.add(root);
    }

    public static void main(String[] args) {
        new MasterMainView();
    }
}

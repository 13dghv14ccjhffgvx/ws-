package com.huangjunqiang.www.View.MasterView;
import com.huangjunqiang.www.Util.JdbcUtils;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.sql.PreparedStatement;
import java.sql.Connection;

/**
 * Create with IntelliJ IDEA
 *
 * @author: hjq
 * @Date:
 * @Description:
 */
public class UserMasterView extends JFrame {
    private Connection conn;
    private PreparedStatement ps;
    private ResultSet rs;
    JLabel usernameLabel=new JLabel("用户名: ");
    JTextField usernameField=new JTextField(15);
    JButton okButton=new JButton("确定");
    JButton cancelButton=new JButton("取消");
    JButton freshButton=new JButton("刷新");
    JButton backButton=new JButton("返回");
    JButton noButton=new JButton("封禁");
    public UserMasterView(){
        JFrame frame = new JFrame();
        DefaultTableModel dtm = new DefaultTableModel();
        DefaultTableCellRenderer dtr = new DefaultTableCellRenderer();
        dtr.setHorizontalAlignment(JLabel.CENTER);
        JTable table = new JTable(stuTableModel(dtm));
        table.setRowHeight(60);
        table.setDefaultRenderer(Object.class, dtr);
        JScrollPane jsp = new JScrollPane();
        jsp.setViewportView(table);
        frame.add(jsp);
        frame.setBounds(50, 10, 1400, 300);
        JPanel panel = new JPanel();
        frame.add(panel, BorderLayout.NORTH);
        JPanel root = new JPanel();
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MasterMainView();
                dispose();
            }
        });
        freshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new UserMasterView();
            }
        });
        noButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showUser();
            }
        });
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteUser(usernameField);
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        root.add(backButton);
        root.add(freshButton);
        root.add(noButton);
        frame.setTitle("AiDu贴吧用户管理");
        frame.add(root, BorderLayout.SOUTH);
        frame.setVisible(true);
    }
    /**
     * 使用DefaultTableModel导入表中数据
     * @param dtm
     * @return
     */
    private DefaultTableModel stuTableModel(DefaultTableModel dtm) {
        String[] stu = {"序号","用户名", "密码", "昵称","生日"};
        dtm.setColumnIdentifiers(stu);
        Vector v = null;
        try {
            conn = JdbcUtils.getConnection();
            String sql = "select * from user";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                v = new Vector();
                int sno = rs.getInt("id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String name = rs.getString("name");
                String birthday=rs.getString("birthday");
                v.add(sno);
                v.add(username);
                v.add(password);
                v.add(name);
                v.add(birthday);
                dtm.addRow(v);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            try{
                if(conn!=null){
                    conn.close();
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return dtm;
    }

    public void showUser(){
        setTitle("输入要封禁的用户名");
        Container container = getContentPane();
        setBounds(520, 330, 400, 180);
        //添加一块桌布
        container.setLayout(new BorderLayout());
        JPanel root = new JPanel();
        root.setLayout(null);
        Font f = new Font("宋体", Font.PLAIN, 25);
        usernameLabel.setFont(f);
        usernameLabel.setBounds(40, 1, 130, 60);
        usernameField.setBounds(150, 17, 150, 30);
        okButton.setBounds(80,80,80,50);
        cancelButton.setBounds(200,80,80,50);
        root.add(usernameLabel);
        root.add(usernameField);
        root.add(okButton);
        root.add(cancelButton);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
        container.add(root);
    }
    public void deleteUser(JTextField nameField){
        String username = nameField.getText();
        try {
            conn = JdbcUtils.getConnection();
            String sql = "delete from user where username =?";
            ps = conn.prepareStatement(sql);
            ps.setString(1,username);
            ps.execute();
            JOptionPane.showMessageDialog(null, "封禁成功");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"封禁失败");
            e.printStackTrace();
        } finally {
            JdbcUtils.close(conn,ps);
        }
    }
    public static void main(String[] args) {
        new UserMasterView();
    }
}

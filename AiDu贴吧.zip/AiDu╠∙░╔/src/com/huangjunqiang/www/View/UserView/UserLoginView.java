package com.huangjunqiang.www.View.UserView;

import com.huangjunqiang.www.Dao.UserLoginDao;
import com.huangjunqiang.www.Util.JdbcUtils;
import com.huangjunqiang.www.Util.StringUtil;
import com.huangjunqiang.www.po.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

/**
 * Create with IntelliJ IDEA
 *
 * @author: hjq
 * @Date:
 * @Description:
 */
public class UserLoginView extends JFrame {
    private final Container container=getContentPane();
    private final JLabel userLabel=new JLabel("用户名: ");
    public static JTextField usernameField=new JTextField(15);
    private final JLabel pwdLabel=new JLabel("密    码: ");
    private final JPasswordField pwdField=new JPasswordField(15);
    private final JButton loginButton=new JButton("登录");
    private final JButton registerButton=new JButton("注册");
    private Connection conn =null;
    private UserLoginDao u=new UserLoginDao();
    private UserRegisterView r=new UserRegisterView();
    public UserLoginView(){
        setTitle("用户登录界面");
        //设置窗口大小
        setBounds(600,300,400,200);
        //添加一块桌布
        container.setLayout(new BorderLayout());
        //初始化窗口
        init();
        //设计窗口可见
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void init() {
        JPanel root = new JPanel();
        root.setLayout(null);
        userLabel.setBounds(70, 30, 50, 20);
        pwdLabel.setBounds(70, 70, 50, 20);
        root.add(userLabel);
        root.add(pwdLabel);
        usernameField.setBounds(130, 30, 160, 20);
        pwdField.setBounds(130, 70, 160, 20);
        root.add(usernameField);
        root.add(pwdField);
        loginButton.setBounds(100,116,65,35);
        registerButton.setBounds(200,116,65,35);
        root.add(loginButton);
        root.add(registerButton);
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loginActionPerformed(e);
            }
        });
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               r.RegisterView();
                dispose();
            }
        });
        container.add(root);
    }

    private void loginActionPerformed(ActionEvent e) {
        String username =usernameField.getText();
        String password =pwdField.getText();
        if(StringUtil.isEmpty(username)){
            JOptionPane.showMessageDialog(null,"用户名不能为空!");
            return;
        }if(StringUtil.isEmpty(password)){
            JOptionPane.showMessageDialog(null,"密码不能为空!");
            return;
        }
        User user = new User(username,password);
        try {
            conn = JdbcUtils.getConnection();
            User currentUser =u.login(conn,user);
            if(currentUser!=null){
                JOptionPane.showMessageDialog(null,"登陆成功");
                new UserMainView();
                dispose();
            }else{
                JOptionPane.showMessageDialog(null,"用户名或密码错误");
            }
        }catch (Exception ex) {
            ex.printStackTrace();
        }finally {
            try{
                if(conn!=null){
                    conn.close();
                }
            }catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}

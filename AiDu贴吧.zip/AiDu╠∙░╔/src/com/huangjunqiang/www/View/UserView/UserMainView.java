package com.huangjunqiang.www.View.UserView;

import com.huangjunqiang.www.Dao.SearchStar;
import com.huangjunqiang.www.View.BarView;
import com.huangjunqiang.www.View.PostView;
import com.huangjunqiang.www.View.StartView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Create with IntelliJ IDEA
 *
 * @author: hjq
 * @Date:
 * @Description:
 */
public class UserMainView extends JFrame{
    private final Container container =getContentPane();
    private final JButton informationButton=new JButton("信息管理");
    private final JButton postMessageButton=new JButton("逛贴之旅");
    private final JButton searchButton=new JButton("收藏的帖子");
    private final JButton backButton=new JButton("返回始界面");
    private UserRegisterView r=new UserRegisterView();
    public UserMainView() {
        setTitle("用户主界面");
        //设置窗口大小
        setBounds(620,60,400,820);
        //添加一块桌布
        container.setLayout(new BorderLayout());
        //初始化窗口
        init();
        //设计窗口可见
        setVisible(true);
    }
    public void init() {
        JPanel root = new JPanel();
        root.setLayout(null);
        informationButton.setBounds(5,1,370,170);
        informationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                r.user();
            }
        });
        postMessageButton.setBounds(5,200,370,170);
        postMessageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PostView().masterPost();
            }
        });
        searchButton.setBounds(5,400,370,170);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new StartView();
                dispose();
            }
        });
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SearchStar();
                dispose();
            }
        });
        backButton.setBounds(5,600,370,170);
        root.add(informationButton);
        root.add(postMessageButton);
        root.add(backButton);
        root.add(searchButton);
        container.add(root);
    }

    public static void main(String[] args) {
        new UserMainView();
    }

}

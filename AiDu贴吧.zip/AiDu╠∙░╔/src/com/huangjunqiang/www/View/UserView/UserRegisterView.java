package com.huangjunqiang.www.View.UserView;

import com.huangjunqiang.www.Dao.UserRegisterDao;
import com.huangjunqiang.www.Util.JdbcUtils;
import com.huangjunqiang.www.Util.StringUtil;
import com.huangjunqiang.www.po.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Create with IntelliJ IDEA
 *
 * @author: hjq
 * @Date:
 * @Description:
 */
public class UserRegisterView extends JFrame {
    private final Container container =getContentPane();
    private final JLabel nicknameLabel =new JLabel("昵    称: ");
    private final JTextField nicknameField=new JTextField(15);
    private final JLabel usernameLabel=new JLabel("用 户 名: ");
    private final JTextField usernameField=new JTextField(15);
    private final JLabel pwdLabel=new JLabel("密    码: ");
    private final JTextField pwdField=new JPasswordField(15);
    private final JLabel birthdayLabel=new JLabel("生    日: ");
    private final JTextField birthdayField=new JTextField(15);
    private final JButton okButton=new JButton("确定");
    private final JButton cancelButton=new JButton("取消");
    private final JButton searchButton = new JButton("查看");
    private final JButton updateButton = new JButton("修改");
    private final JButton resetButton = new JButton("重置");
    Connection conn=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    UserRegisterDao u=new UserRegisterDao();
    public void RegisterView() {
        setTitle("用户注册界面");
        //设置窗口大小
        setBounds(560,200,520,450);
        //添加一块桌布
        container.setLayout(new BorderLayout());
        //初始化窗口
        init();
        //设计窗口可见
        setVisible(true);
    }
    private void init() {
        JPanel root = new JPanel();
        root.setLayout(null);

        Font f= new Font("宋体",Font.PLAIN,25);
        usernameLabel.setBounds(30,2,130,80);
        usernameField.setBounds(155,23,300,40);
        pwdLabel.setBounds(30,82,130,80);
        pwdField.setBounds(155,103,300,40);
        nicknameLabel.setBounds(30,162,130,80);
        nicknameField.setBounds(155,183,300,40);
        birthdayLabel.setBounds(30,232,130,80);
        birthdayField.setBounds(155,253,300,40);
        nicknameLabel.setFont(f);
        usernameLabel.setFont(f);
        pwdLabel.setFont(f);
        birthdayLabel.setFont(f);
        root.add(usernameLabel);
        root.add(usernameField);
        root.add(pwdLabel);
        root.add(pwdField);
        root.add(nicknameLabel);
        root.add(nicknameField);
        root.add(birthdayLabel);
        root.add(birthdayField);
        okButton.setBounds(100,330,100,50);
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerActionPerformed(e);
            }
        });
        cancelButton.setBounds(300,330,100,50);
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new UserLoginView();
                dispose();
            }
        });
        root.add(okButton);
        root.add(cancelButton);
        container.add(root);
    }
    private void registerActionPerformed(ActionEvent e) {
        String username = this.usernameField.getText();
        String password = this.pwdField.getText();
        String nickname = this.nicknameField.getText();
        String birthday =this.birthdayField.getText();
        if (StringUtil.isEmpty(username)) {
            JOptionPane.showMessageDialog(null, "用户名不能为空!");
            return;
        }
        if (StringUtil.isEmpty(password)) {
            JOptionPane.showMessageDialog(null, "密码不能为空!");
            return;
        }
        if (StringUtil.isEmpty(nickname)) {
            JOptionPane.showMessageDialog(null, "昵称不能为空!");
            return;
        }
        if (StringUtil.isEmpty(birthday)) {
            JOptionPane.showMessageDialog(null, "生日不能为空!");
            return;
        }
        try {
            User user = new User(username, password,nickname,birthday);
            conn = JdbcUtils.getConnection();
            int result= u.register(conn,user);
            if (result != 0) {
                JOptionPane.showMessageDialog(null, "注册成功");
                new UserLoginView();
                dispose();
            }else{
                JOptionPane.showMessageDialog(null, "注册失败");
            }
        } catch (HeadlessException ex) {
            ex.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    public void user(){
        Container container=getContentPane();
        setBounds(570, 130, 450, 500);
        container.setLayout(new BorderLayout());
        setTitle("个人信息(输入用户名进行操作)");
        JPanel j = new JPanel();
        j.setLayout(null);
        Font f = new Font("宋体", Font.PLAIN, 25);
        usernameLabel.setBounds(10, 40, 130, 60);
        usernameField.setBounds(130, 53, 280, 40);
        pwdLabel.setBounds(10, 120, 130, 60);
        pwdField.setBounds(130, 133, 280, 40);
        nicknameLabel.setBounds(10, 200, 130, 60);
        nicknameField.setBounds(130, 213, 280, 40);
        birthdayLabel.setBounds(10, 280, 130, 60);
        birthdayField.setBounds(130, 293, 280, 40);
        usernameLabel.setFont(f);
        pwdLabel.setFont(f);
        nicknameLabel.setFont(f);
        birthdayLabel.setFont(f);
        j.add(usernameLabel);
        j.add(usernameField);
        j.add(pwdLabel);
        j.add(pwdField);
        j.add(nicknameLabel);
        j.add(nicknameField);
        j.add(birthdayLabel);
        j.add(birthdayField);
        searchButton.setBounds(40, 370, 100, 50);
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                search();
            }
        });
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reset(usernameField,pwdField,nicknameField,birthdayField);
            }
        });
        updateButton.setBounds(170,370,100,50);
        resetButton.setBounds(300,370,100,50);
        j.add(searchButton);
        j.add(updateButton);
        j.add(resetButton);
        container.add(j);
        setVisible(true);
    }

    public void search(){
        String name=usernameField.getText();
        boolean flag=false;
        try {
            conn = JdbcUtils.getConnection();
            conn.setAutoCommit(false);
            String sql = "select * from user where username=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1,name);
            rs = ps.executeQuery();
            while(rs.next()){
                String sName = rs.getString("username");
                if(name.equals(sName)){
                    usernameField.setText(rs.getString("username"));
                    pwdField.setText(rs.getString("password"));
                    nicknameField.setText(rs.getString("name"));
                    birthdayField.setText(rs.getString("birthday"));
                    flag=true;
                }
            }
            if(flag) {
                JOptionPane.showMessageDialog(null, "查询成功");
            }else{JOptionPane.showMessageDialog(null,"查询失败");}
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"查询失败");
            e.printStackTrace();
        }finally{
            JdbcUtils.close(conn,ps,rs);
        }
    }

    public void reset(JTextField username,JTextField pwd,JTextField nickname,JTextField birthday){
        username.setText("");
        pwd.setText("");
        nickname.setText("");
        birthday.setText("");
    }

    public static void main(String[] args) {
        UserRegisterView r =new UserRegisterView();
        r.user();
    }
}
